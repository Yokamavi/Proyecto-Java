package Hijos;
import Padre.Planeta;
/**
 * Clase Planeta Azul
 * @author Aarón Martíns Vilas
 * @author Víctor Mosquera Puchades
 * @author Liliana Ortega Arteaga
 * @author Óscar Rama Blanco
 * @author Gabriela Salazar Franco
 * @author Fabián Sanchez Rodriguez
 * @version 3.0
 * @since 1.0
 */
public class Nietzsche extends Planeta {

	public Nietzsche() {
		super(200, 50);
	}
	public String combate(int misilesLanzados, Planeta atacado) {
		int misilesImpactados = 0;
		String evento = "";

		// Simulación de esquiva (el Enano tiene un 50% de probabilidad de esquivar cada misil)
		if (atacado instanceof SunTzu) {
			for (int i = 0; i < misilesLanzados; i++) {
				misilesImpactados += (Math.random() >= 0.5) ? 1 : 0;
			}
		} else {
			misilesImpactados = misilesLanzados;
		}

		// Cálculo de ventajas y desventajas (Piedra, Papel, Tijera)
		if (atacado instanceof Maquiavelo) { 
			misilesImpactados *= 2;
		} 
		else if (atacado instanceof Marx) {
			misilesImpactados /= 2;
		}
		// 	Aplicamos el daño final al pobrecito atacado
		atacado.setVidas(atacado.getVidas() - misilesImpactados);

		this.misilesRonda -= misilesLanzados; // Gastamos nuestros misiles

		evento = "🚀 [" + nombre.replace('.', ' ') + "] lanzó " + misilesLanzados + " misiles a [" + atacado.getNombre().replace('.', ' ') + "]. ";

		if (atacado instanceof SunTzu) {
			evento += "💨 El Enano esquivó " + (misilesLanzados-misilesImpactados) + " misiles. ";
		}
		evento += "(- " + misilesImpactados + " HP).\n";
		return evento;
	}

}