package Hijos;
import Padre.Planeta;
/**
 * Clase Planeta Gigante
 * @author Aarón Martíns Vilas
 * @author Víctor Mosquera Puchades
 * @author Liliana Ortega Arteaga
 * @author Óscar Rama Blanco
 * @author Gabriela Salazar Franco
 * @author Fabián Sanchez Rodriguez
 * @version 3.0
 * @since 1.0
 */
public class Hobbes extends Planeta {

	public Hobbes() {
		super(400,10);
	}
	public String combate(int misilesLanzados, Planeta atacado) {
		int misilesImpactados = 0;
		String evento = "";

		// Simulación de esquiva (el Enano tiene un 50% de probabilidad de esquivar cada misil)
		if (atacado instanceof SunTzu) {
			for (int i = 0; i < misilesLanzados; i++) {
				misilesImpactados += (Math.random() >= 0.5) ? 1 : 0;
			}
		} else {
			misilesImpactados = misilesLanzados;
		}

		// Aplicamos el daño final al pobrecito atacado
		atacado.setVidas(atacado.getVidas() - misilesImpactados);
		this.misilesRonda -= misilesLanzados; // Gastamos nuestros misiles

		evento = "🚀 [" + nombre.replace('.', ' ') + "] lanzó " + misilesLanzados + " argumentos a [" + atacado.getNombre() + "]. ";

		if (atacado instanceof SunTzu) {
			evento += "💨 Sun Tzu esquivó " + (misilesLanzados-misilesImpactados) + " argumentos. ";
		}
		evento += "(- " + misilesImpactados + "de reputación).\n";
		return evento;
	}




}