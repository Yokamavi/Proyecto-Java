package Principal;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Scanner;
import Ficheros.Fichero;
import Hijos.Nietzsche;
import Hijos.SunTzu;
import Hijos.Hobbes;
import Hijos.Platon;
import Hijos.Maquiavelo;
import Hijos.Marx;
import MostrarInfo.MostrarInfo;
import Padre.Planeta;
import coldWar_Utils.CrearId;

/**
 * Clase principal donde arranca el juego Coldwar. Aquí está el menú, 
 * la preparación de la partida, los turnos y la lista de ganadores.
 * @author Aarón Martíns Vilas
 * @author Víctor Mosquera Puchades
 * @author Liliana Ortega Arteaga
 * @author Óscar Rama Blanco
 * @author Gabriela Salazar Franco
 * @author Fabián Sanchez Rodriguez
 * @version 3.0
 * @since 1.0
 */
public class Main {
	static Scanner e = new Scanner(System.in);

	/**
	 * Punto de partida del programa. Enseña el logo y te deja en el menú principal 
	 * dando vueltas hasta que decidas salir poniendo un 0.
	 * * @param args Argumentos de la línea de comandos (no los usamos).
	 */
	public static void main(String[] args) {
		int opciones = 0;
		MostrarInfo.mostrarLogo();

		// Mantiene el programa en ejecución mostrando el menú principal continuamente
		// hasta que el usuario introduce la opción de salida (0).
		do {
			opciones = mostrarMenu();
			switch (opciones) {
			case 1:
				jugar();
				break;
			case 2:
				MostrarInfo.mostrarReglas();
				break;
			case 3:
				MostrarInfo.mostrarInformacion();
				break;
			case 4:
				Fichero.mostrarGanadores();
				break;
			case 0:
				salir();
				break;
			}
		} while (opciones != 0);
	}

	/**
	 * Prepara todo antes de empezar a jugar. Te pregunta el modo de juego, 
	 * cuántos equipos van a participar y cómo quieres configurar las vidas y los misiles.
	 */
	public static void jugar() {
		MostrarInfo.mostrarMenuPartida();
		int opcion = 0;
		do {
			System.out.print("Introduce opcion (0-1): ");
			opcion = pedirNumero();
			if (opcion < 0 || opcion > 1) {
				System.out.println("❌ Número fuera de rango.");
			}
		} while (opcion < 0 || opcion > 1);
		// Volver
		if (opcion == 0) {
			return;
		}

		System.out.print("¿Cuántos equipos van a participar? (Mínimo 3): ");
		int numEquipos = 0;
		do {
			numEquipos = pedirNumero();
			if (numEquipos < 3) {
				System.out.print("❌ Tienen que ser al menos 3 equipos. Inténtalo de nuevo: ");
			}
		} while (numEquipos < 3);

		ArrayList<Planeta> equipos = new ArrayList<>();
		int misilesIniciales = 50;
		int vida = 200;

		iniciarPartida(equipos, misilesIniciales, numEquipos, vida);
	}

	/**
	 * Crea los equipos y controla los turnos de la partida. Se encarga de que 
	 * los jugadores ataquen, se curen, mueran y de ver quién gana al final.
	 * * @param equipos          Lista donde vamos a guardar los planetas que juegan.
	 * @param misilesIniciales Los misiles con los que empieza cada equipo.
	 * @param numEquipos       Cuántos jugadores hay en total.
	 * @param vidaPers         La vida inicial si se eligió un modo personalizado o con bots.
	 */
	public static void iniciarPartida(ArrayList<Planeta> equipos, int misilesIniciales, int numEquipos, int vida) {
		String eventos = "";
		int ronda = 1;

		System.out.println("\n--- Bienvenido a Coldwar ---");
		System.out.println("Creando equipos...");

			for (int i = 0; i < numEquipos; i++) {
				boolean nombreValido= false;
				String nombre = "";
				do {
					nombreValido = true;
					System.out.print("\nInserta el nombre del equipo Nº" + (i + 1) + ": ");
					nombre = e.nextLine().trim();
					if (nombre.isEmpty()) {
						System.out.println("❌ El nombre no puede estar vacío.");
						nombreValido = false;
						continue;
					} else if (nombre.endsWith(".")) {
						System.out.println("❌ El nombre no puede terminar en punto.");
						nombreValido = false;
						continue;
					}
					// Verificamos que el nombre introducido no esté ya en uso por otro jugador 
					// en la lista actual para evitar conflictos de identificación.
					for (int j = 0; j < equipos.size(); j++) {
						if (equipos.get(j).getNombre().equalsIgnoreCase(nombre)) {
							System.out.println("❌ Ese nombre ya está en uso. Por favor, elige otro.");
							nombreValido = false;
							break;
						}
					}
				} while (!nombreValido);

				Planeta nuevoPlaneta = null;
					MostrarInfo.mostrarTipoPlaneta();
					int tipoPlaneta = 0;
					do {
						System.out.print("Introduce el tipo (1-6): ");
						tipoPlaneta = pedirNumero();
						if (tipoPlaneta < 1 || tipoPlaneta > 6) {
							System.out.println("❌ Opción inválida. Debe ser entre 1 y 6.");
						}
					} while (tipoPlaneta < 1 || tipoPlaneta > 6);
					if(tipoPlaneta == 1) {
						nuevoPlaneta = new Platon();
					}else if(tipoPlaneta == 2) {
						nuevoPlaneta = new Maquiavelo();
					}else if(tipoPlaneta == 3) {
						nuevoPlaneta = new Nietzsche();
					}else if(tipoPlaneta == 4) {
						nuevoPlaneta = new Marx();
					}else if(tipoPlaneta == 5) {
						nuevoPlaneta = new Hobbes();
					}else if(tipoPlaneta == 6) {
						nuevoPlaneta = new SunTzu();
					}			
				nuevoPlaneta.setNombre(nombre);
				@SuppressWarnings("unused")
				String id = CrearId.crearIdManual();
				nuevoPlaneta.setId(id);
				equipos.add(nuevoPlaneta);
			}
		

		// Repetimos el siguiente bucle mientras queden 2 equipos vivos o más
		while (contarVivos(equipos) >= 2) {
			System.out.println("\n==================================");
			System.out.println("          RONDA " + ronda);
			System.out.println("==================================");
			imprimirEstadoEquipos(equipos);

			boolean[] empezoRondaVivo = new boolean[equipos.size()];
			int[] vidaInicialRonda = new int[equipos.size()];

			// Capturamos una instantánea de la salud de todos los participantes justo al inicio, en caso de que su salud
			// sea mayor a 0 los guadamos en el array empezoRondaVivo para que así no pierdan su turno en caso de morir en esa misma ronda
			for (int i = 0; i < equipos.size(); i++) {
				empezoRondaVivo[i] = equipos.get(i).getVidas() > 0;
				vidaInicialRonda[i] = equipos.get(i).getVidas();
			}
			//Emezamos con los turnos de cada equipo
			for (int i = 0; i < equipos.size(); i++) {
				Planeta atacante = equipos.get(i);

				// Omitimos el turno en caso de que el equipo no estuviese vivo
				if (!empezoRondaVivo[i]) {
					continue;
				}else {
					while (atacante.getMisilesRonda() > 0) {
						System.out.println("\n------------------------------------------");
						System.out.println("Turno de: " + atacante.getNombre() + " (" + vidaInicialRonda[i] + " HP)");
						System.out.println("Misiles disponibles: " + atacante.getMisilesRonda());
						System.out.println("------------------------------------------");

						Planeta[] objetivos = new Planeta[equipos.size()];
						int opcionesDisponibles = mostrarObjetivos(atacante, equipos, objetivos, ronda, vidaInicialRonda);
						int opcion = -1;
						do {
							System.out.print("¿Qué deseas hacer?: ");
							opcion = pedirNumero();
							if (opcion < 0 || opcion > opcionesDisponibles) {
								System.out.println("❌ Opción no válida.");
							} else if (opcion == 0 && ronda == 1) {
								System.out.println("❌ ¡No puedes defenderte en la primera ronda!");
								opcion = -1; 
							}
						} while (opcion < 0 || opcion > opcionesDisponibles);

						if (opcion == 0) {
							System.out.print("¿Cuántos misiles vas a usar para defenderte?: ");
							int misilesDefensa = pedirMisilesValidos(atacante.getMisilesRonda());
							eventos += atacante.curar(misilesDefensa);
						} else {
							System.out.print("¿Cuántos misiles vas a lanzar?: ");
							int misilesLanzar = pedirMisilesValidos(atacante.getMisilesRonda());
							Planeta objetivo = objetivos[opcion - 1];
							eventos += atacante.combate(misilesLanzar, objetivo);
						}
					}

				}
			}

			// Al final de la ronda observamos quienes han muerto y los añadimos al registor 
			eventos += "\n--- RESUMEN DE BAJAS DE LA RONDA ---\n";
			boolean huboBajas = false;
			for (int i = 0; i < equipos.size(); i++) {
				if (empezoRondaVivo[i] && equipos.get(i).getVidas() <= 0) {
					eventos += "☠️ ¡EL EQUIPO " + equipos.get(i).getNombre().toUpperCase().replace('.', ' ')
							+ " HA SIDO DESTRUIDO!\n";
					huboBajas = true;
				}
			}

			// En caso de no haber bajas tambien lo informamos
			eventos += huboBajas ? "" : "Nadie ha sido destruido en esta ronda.\n";
			imprimirRegistro(eventos, ronda);
			eventos = ""; // Reiniciamos el registro de la ronda

			// Comprobamos si aun quedan 2 o mas equipos vivos
			if (contarVivos(equipos) <= 1) {
				// EN caso de que solo quede un equipo vivo se declarará a ese equipo como ganador
			    Planeta ganador = obtenerGanador(equipos);
				if (ganador != null) {
				    System.out.println("🏆 ¡LA GUERRA HA TERMINADO! El ganador es: "
				        + ganador.getNombre() + " (ID: " + ganador.getId() + ")");
				} else {
				    System.out.println("🏆 ¡LA GUERRA HA TERMINADO! Empate.");
				}
				return;
				}
				ronda++;
				for (Planeta p : equipos) {
				    if (p.getVidas() > 0) {
				        p.rellenarMisiles(p instanceof Hobbes ? 10 * ronda : misilesIniciales);
				}
			}
		}
}

	/**
	 * Muestra el menú principal en pantalla y te pide que elijas una opción.
	 * * @return El número de la opción que ha elegido el usuario (del 0 al 4).
	 */
	public static int mostrarMenu() {
		MostrarInfo.mostrarMenu();
		int opciones = 0;
		do {
			System.out.print("Elige una opción (0-4): ");
			opciones = pedirNumero();
		} while (opciones < 0 || opciones > 4); 
		return opciones;
	}

	/**
	 * Simplemente muestra un mensaje para despedirse cuando cierras el juego.
	 */
	public static void salir() {
		System.out.println("Fin del juego");
	}

	/**
	 * Pide un número por teclado y se asegura de que no metas letras por error, 
	 * así evitamos que el programa se rompa (salte una excepción).
	 * * @return El número que ha escrito el usuario.
	 */
	public static int pedirNumero() {
		int cantidad = -1;
		boolean esNumero = false;
		do {
			try {
				String input = e.nextLine().trim();
				if (input.isEmpty()) {
					System.out.print("Por favor, introduce un número: ");
					continue;
				}
				cantidad = Integer.parseInt(input);
				esNumero = true;
			} catch (NumberFormatException ex) {
				System.out.print("No es un número válido. Intenta de nuevo: ");
			}
		} while (!esNumero);
		return cantidad;
	}

	/**
	 * Te pregunta cuántos misiles quieres usar y vigila que no intentes gastar 
	 * más de los que tienes o menos de 1.
	 * * @param maximoDisponible El tope de misiles que puedes gastar en este turno.
	 * @return Los misiles que finalmente vas a usar.
	 */
	public static int pedirMisilesValidos(int maximoDisponible) {
		int cantidad = -1;
		do {
			cantidad = pedirNumero();
			if (cantidad < 1) {
				System.out.print("Debes usar al menos 1: ");
			} else if (cantidad > maximoDisponible) {
				System.out.print("Solo tienes " + maximoDisponible + " misiles: ");
			}
		} while (cantidad < 1 || cantidad > maximoDisponible);
		return cantidad;
	}

	/**
	 * Muestra en pantalla la vida que le queda a cada equipo. Si es el modo de juego
	 * "Normal", también te avisa de qué tipo de planeta es cada uno (Rojo, Azul, etc.).
	 * * @param equipos     La lista con todos los planetas de la partida.
	 */
	public static void imprimirEstadoEquipos(ArrayList<Planeta> equipos) {
		for (Planeta p : equipos) {
			if (p.getVidas() > 0) {
					System.out.println("[+] " + p.getNombre() + "----> " + p.getVidas() + " HP");
		
			} else {
				System.out.println("[-] " + p.getNombre() + " ---> DESTRUIDO");
			}
		}
	}

	/**
	 * Muestra a quién puedes atacar en tu turno (solo a los que siguen vivos) y 
	 * te da la opción de curarte si no estás en la primera ronda.
	 * @param atacante         El planeta al que le toca jugar ahora.
	 * @param equipos          Todos los equipos de la partida.
	 * @param objetivos        Un array que usamos para saber a qué enemigo corresponde cada número del menú.
	 * @param ronda            La ronda actual (para saber si bloquear la opción de defenderse).
	 * @param vidaInicialRonda Las vidas al empezar la ronda, para no dejarte atacar a alguien que acaba de morir.
	 * @return El número máximo de opciones que hay en el menú para atacar.
	 */
	public static int mostrarObjetivos(Planeta atacante, ArrayList<Planeta> equipos, Planeta[] objetivos, int ronda,
			int[] vidaInicialRonda) {
		int pos = 0;
		for (int i = 0; i < equipos.size(); i++) {
			Planeta p = equipos.get(i);
			if (p != atacante && vidaInicialRonda[i] > 0) {
				objetivos[pos] = p;
				if (!atacante.getNombre().endsWith(".")) {
					System.out.println((pos + 1) + ". Atacar a " + p.getNombre().replace('.', ' ') + " ("
							+ vidaInicialRonda[i] + " HP)");
				}
				pos++;
			}
		}

		if (!atacante.getNombre().endsWith(".")) {
			System.out.println(ronda == 1 ? "0. Defender (BLOQUEADO EN RONDA 1)" : "0. Defender y recuperar HP");
		}
		return pos;
	}

	/**
	 * Imprime un bloque de texto bonito con todo lo que ha pasado durante la ronda 
	 * (los ataques, curaciones, muertes...).
	 * * @param eventos Todo el texto con lo que ha pasado.
	 * @param ronda   El número de la ronda que acaba de terminar.
	 */
	public static void imprimirRegistro(String eventos, int ronda) {
		MostrarInfo.mostrarRegistro(ronda, eventos);
	}

	/**
	 * Cuenta cuántos equipos siguen con vida (con vida mayor que cero).
	 * * @param equipos La lista de todos los planetas.
	 * @return El número de supervivientes.
	 */
	public static int contarVivos(ArrayList<Planeta> equipos) {
		int vivos = 0;
		for (Planeta p : equipos) {
			if (p.getVidas() > 0) {
				vivos++;
			}
		}
		return vivos;
	}

	/**
	 * Busca qué equipo ha ganado (el último que queda vivo), guarda su nombre 
	 * en un archivo de texto llamado ganadores_coldwar.txt y te dice quién es.
	 * * @param equipos La lista de equipos cuando la partida ya ha acabado.
	 * @return El nombre del ganador o "Nadie" si ha habido un empate raro.
	 */
	public static Planeta obtenerGanador(ArrayList<Planeta> equipos){
		for (Planeta p : equipos) {
	        if (p.getVidas() > 0) {
	            Fichero.guardarFichero(p); // ahora pasamos el objeto entero
	            return p;
	        }
	    }


	    Fichero.guardarFichero(null); // empate
	    return null;
	}


	/**
	 * Saca un número aleatorio que esté entre el mínimo y el máximo que le pases. 
	 * Se usa para que los ataques de los bots sean impredecibles o para elegir nombres.
	 * * @param minimo El número más pequeño que quieres que pueda salir.
	 * @param maximo El número más grande que quieres que pueda salir.
	 * @return Un número al azar entre esos dos.
	 */
	public static int numAleatorio(int minimo, int maximo) {
		return (int) (Math.random() * (maximo - minimo + 1)) + minimo;
	}


}