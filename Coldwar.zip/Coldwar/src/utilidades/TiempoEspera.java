
package utilidades;
public class TiempoEspera {
	public static void tiempo(long milisegundos) {
		try {
			Thread.sleep(milisegundos);
		} catch (InterruptedException e) {
			Thread.currentThread().interrupt(); 
		}
	}
}

